function [bitN] = genBin(M,T)
%genBin Summary of this function goes here
% Generation of a binary sequence
bitN = randi([0,1],M,T);
end

