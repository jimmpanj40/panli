function [bitN] = genBin(N)
%genBin Summary of this function goes here
% Generation of a binary sequence
bitN = randi([0,1],1,N);
end

